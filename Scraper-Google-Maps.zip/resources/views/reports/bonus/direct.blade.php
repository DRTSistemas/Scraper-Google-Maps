@extends('layouts.app', ['title' => __('Reports'), 'page' => 'reports'])

@section('content')
    <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
        <div class="container-fluid">
            <div class="header-body">
                <!-- Card stats -->
                <div class="row justify-content-center">
                    <div class="col-xl-3 col-lg-6">
                        <div class="card card-stats mb-4 mb-xl-0">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <h5 class="card-title text-uppercase text-muted mb-0">Confirmed</h5>
                                        <span class="h2 font-weight-bold mb-0">
                                            {{ $totalConfirmed }} USDT
                                        </span>
                                    </div>
                                    <div class="col-auto">
                                        <div class="icon icon-shape bg-danger text-white rounded-circle shadow">
                                            <i class="fas fa-money-check-alt"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-6">
                        <div class="card card-stats mb-4 mb-xl-0">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <h5 class="card-title text-uppercase text-muted mb-0">Pending</h5>
                                        <span class="h2 font-weight-bold mb-0">
                                            {{ $totalPending }} USDT
                                        </span>
                                    </div>
                                    <div class="col-auto">
                                        <div class="icon icon-shape bg-warning text-white rounded-circle shadow">
                                            <i class="fas fa-dollar-sign"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-6">
                        <div class="card card-stats mb-4 mb-xl-0">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <h5 class="card-title text-uppercase text-muted mb-0">Total</h5>
                                        <span class="h2 font-weight-bold mb-0">{{ $directs->sum('value')  }} USDT</span>
                                    </div>
                                    <div class="col-auto">
                                        <div class="icon icon-shape bg-yellow text-white rounded-circle shadow">
                                            <i class="fas fa-hand-holding-usd"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col-xl-12 order-xl-1">
                <div class="card bg-secondary shadow">
                    <div class="card-header bg-white border-0">
                        <div class="row align-items-center">
                            <h3 class="col-12 mb-0">{{ __('Bonus Direct') }}</h3>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <!-- Projects table -->
                        <table class="table align-items-center table-flush">
                            <thead class="thead-light">
                            <tr>
                                <th scope="col">Plan</th>
                                <th scope="col" class="text-center">From</th>
                                <th scope="col" class="text-center">Pay Value</th>
                                <th scope="col" class="text-center">Status</th>
                                <th scope="col" class="text-right">Date</th>

                            </tr>
                            </thead>
                            <tbody>
                            @foreach($directs as $direct)
                                <tr>
                                    <th>
                                        @if(!empty($direct->userPlan()->plan()))
                                            {{ substr(sha1($direct->userPlan()->id), -4) }}
                                        @else
                                            Donation
                                        @endif
                                    </th>
                                    <td class="text-center">
                                        {{ $direct->donation()->user()->username }}
                                    </td>
                                    <td class=$direct>
                                        {{ $direct->value }} USDT
                                    </td>
                                    <th  class="text-center">
                                        @if($direct->userPlan()->status == 2)
                                            Confirmed
                                        @elseif($direct->userPlan()->status == 1)
                                            Waiting
                                        @else
                                            Cancelled
                                        @endif
                                    </th>
                                    <td class="text-right">
                                        {{ $direct->created_at->format('j F, Y') }}
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                        {{ $directs->links() }}
                    </div>
                </div>
            </div>
        </div>

        @include('layouts.footers.auth')
    </div>
@endsection
