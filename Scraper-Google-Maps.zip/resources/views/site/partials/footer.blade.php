<footer id="rodape">
    <div class="barra-cima2"></div> <!-- Fim barra -->
    <div id="oitava-pagina"> <!-- Duvidas -->
        <div id="contact" class="duvidas">
            <div class="row">
                <div class="col-sm-4 offset-sm-2">
                    <img src="/site/img/duvidas.png" class="img-responsive" alt="" title="" />
                </div>
                <div class="col-sm-4">
                    <h1>Doubts</h1>
                    <p>If in doubt, look for the person who referred the community to you or an active member in your region!</p>
                    <span>© 2020 - Seed Community</span>
                </div>
            </div>
        </div>
    </div> <!-- Fim duvidas -->
    <div class="barra-baixo2"></div> <!-- Fim barra -->
</footer>